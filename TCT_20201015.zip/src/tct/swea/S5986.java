package tct.swea;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class S5986 {

public static void main(String[] args) {
		
		int input = 15;
		List<Integer> snList = new ArrayList<Integer>();
		
		for(int i=2 ; i<input ; i++){
			int cnt = 0;
			for(int n=1 ; n<=i ; n++ ){
				if(i%n == 0){
					cnt++;
				}
			}
			if(cnt == 2){
				snList.add(i);
			}
		}
		
		int x = 0,y = 0,z = 0;
		boolean result = false;
		
		for(int a=0 ; a<snList.size() ; a++){
			x = snList.get(a);
			for(int b=a ; b<snList.size() ; b++){
				y = snList.get(b);
				for(int c=b ; c<snList.size() ; c++){
					z = snList.get(c);
					if(x+y+z == input){
						result = true;
						break;
					}
				}
				if(result) break;
			}
			if(result) break;
		}
		
		System.out.println("x : " + x) ;
		System.out.println("y : " + y) ;
		System.out.println("z : " + z) ;
	}
	
}





