package tct.swea.dfs;

import java.util.Stack;

public class S7699 {

	static int[][] map = {{'C','A','A','B'},{'A','D','C','B'}};
	static int[] dx = {-1, 0, 1, 0};
	static int[] dy = {0, 1, 0, -1};
	static int r = 2;
	static int c = 4;
	static int max;
	static int[] visit;

	public static void main(String[] args) {
		
		visit = new int[100];
		max = 0;
		
		for(int i=0 ; i<map.length ; i++){
			for(int j=0 ; j<map[i].length ; j++){
				map[i][j] = map[i][j]-'A';
				System.out.println(map[i][j]);
			}
		}
		dfs(0, 0, 0);
		
		
		
	}

	private static void dfs(int x, int y, int depth) {
		
		System.out.println("map[x][y] : " + map[x][y]);
		visit[map[x][y]] = 1;
		depth++;
		
		if(max < depth){
			max = depth;
		}
		System.out.println("max : " + max);
		
		for(int i = 0; i < 4; i++) {
			int nx = x + dx[i];
			int ny = y + dy[i];
			
			if(nx >= 0 && ny >= 0 && nx < r && ny < c) {
				if(visit[map[nx][ny]] == 0){
					dfs(nx, ny, depth);
				}
			}
//			visit[map[x][y]] = 0;
		}

	}
}





