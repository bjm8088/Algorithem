package tct.swea.dfs;

import java.util.Stack;

public class S1865 {

	static double[][] a = {{0.13, 0.0, 0.5},{0.12, 0.7, 0.9}, {0.25, 0.6, 1.0}};
	static int n;
	static double max;
	static int[] visit;

	public static void main(String[] args) {
		
		n= 3;
		visit = new int[n];
		max = 0.0;
		
		for(int i = 0; i < n; i++) {
			dfs(i, 0, 1.0);
		}
		
	}

	private static void dfs(int x, int depth, Double result) {
		
		result *= a[x][depth];
		visit[x] = 1;
		
		if(depth == n - 1) {
			if(max < result){
				max = result;
			}
			visit[x] = 0;
			System.out.println(max);
			return;
		}
		
		for(int i = 0; i < n; i++) {
			Double teamp = result * a[i][depth+1];
			if(visit[i] == 0 && result * a[i][depth+1] > max){
				dfs(i, depth+1, result);
			}
		}
		visit[x] = 0;

	}
}





