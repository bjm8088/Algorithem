package tct.baek;
import java.util.*;

public class B11725 {

		static int[][] map;
		static boolean[] c;
		static int n;
		
		public static void dfs(int x) {
			c[x] = true;
			
			for(int i = 0; i < n; i++) {
				if(map[x][i] == 1 && c[i] == false) {
					dfs(i);
				}
			}
		}
		
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			n = sc.nextInt();
			map = new int[n][n];
			c = new boolean[n];
			
			int cnt = 0;
			int e = sc.nextInt();
			
			for(int i = 0; i < e; i++) {
				int x = sc.nextInt();
				int y = sc.nextInt();
				map[x-1][y-1] = 1;
				map[y-1][x-1] = 1;
			}
			
			for(int i = 0; i < n; i++) {
				for(int j = 0; j < n; j++) {
					if(map[i][j] == 1 && c[j] == false) {
						cnt++;
						dfs(j);
					}
				}
			}
			
			//��忡 ����� ������ �ϳ��� ���� ���
			for(int i = 0; i < n; i++) {
				int sum = 0;
				for(int j = 0; j < n; j++) {
					sum += map[i][j];
				}
				if(sum == 0)
					cnt++;
			}
			
			System.out.print(cnt);
		}
	}