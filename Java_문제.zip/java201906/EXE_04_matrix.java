package lang.java201906;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EXE_04_matrix {
	
	
	public static void main(String[] args) {

		//���,�⵵,���
		String[][] matrix = {
			    {"R", "G", "B", "B", "R", "G", "G", "R"},
			    {"R", "R", "R", "B", "R", "R", "G", "R"},
			    {"R", "G", "B", "G", "G", "G", "B", "R"},
			    {"R", "G", "R", "B", "G", "R", "G", "G"},
			    {"G", "B", "B", "G", "R", "G", "R", "B"},
			    {"R", "B", "G", "G", "G", "G", "G", "B"},
			    {"R", "R", "B", "R", "B", "R", "B", "R"},
			    {"1", "1", "1", "1", "1", "1", "1", "1"}
			};

		
		String[][] result = function(matrix);
		
		
		System.out.println("Merge Matrix : ");
		for(int i=0 ; i<result.length ; i++){
			for(int j=0 ; j<result[i].length ; j++){
				System.out.print(result[i][j].toString() + "\t");
			}
			System.out.println("");
		}
		
		
	}

	private static String[][] function(String[][] matrix1) {
		
		String[][] matrixR = new String[8][8];
		String[][] matrix2 = new String[8][8];
		
		for(int i=0 ; i<matrix1.length ; i++){
			for(int j=0 ; j<matrix1[i].length ; j++){
				matrixR[j][i] = matrix1[i][j];
			}
		}
		
		for(int i=0 ; i<matrix1.length ; i++){
			String temp = "";
			int begin = 0;
			int end = 0;
			
			for(int j=0 ; j<matrix1[i].length ; j++){
				if(!"1".equals(matrix1[i][j])){
					if(!temp.equals(matrix1[i][j])){
						temp = matrix1[i][j];
						if(end - begin >= 2){
							for(int a=begin ; a<=end ; a++){
								matrix1[i][a] = "0";
							}
						}
						begin = j;
						end =j;
					}else{
						if(j== matrix1[i].length -1){
							if(end - begin >= 2){
								for(int a=begin ; a<=end ; a++){
									matrix1[i][a] = "0";
								}
							}
						}else{
							end++;
						}
					}
				}
			}
		}
		
		System.out.println("Matrix1");
		for(int i=0 ; i<matrix1.length ; i++){
			for(int j=0 ; j<matrix1[i].length ; j++){
				System.out.print(matrix1[i][j].toString() + "\t");
			}
			System.out.println("");
		}
		
		for(int i=0 ; i<matrixR.length ; i++){
			String temp = "";
			int begin = 0;
			int end = 0;
			
			for(int j=0 ; j<matrixR[i].length ; j++){
				if(!"1".equals(matrix1[i][j])){
					if(!temp.equals(matrixR[i][j])){
						temp = matrixR[i][j];
						if(end - begin >= 2){
							for(int a=begin ; a<=end ; a++){
								matrixR[i][a] = "0";
							}
						}
						begin = j;
						end =j;
					}else{
						if(j== matrixR[i].length -1){
							if(end - begin >= 2){
								for(int a=begin ; a<=end ; a++){
									matrixR[i][a] = "0";
								}
							}
						}else{
							end++;
						}
					}
				}
			}
		}
		
		for(int i=0 ; i<matrixR.length ; i++){
			for(int j=0 ; j<matrixR[i].length ; j++){
				matrix2[j][i] = matrixR[i][j];
			}
		}
		
		System.out.println("Matrix1");
		for(int i=0 ; i<matrix2.length ; i++){
			for(int j=0 ; j<matrix2[i].length ; j++){
				System.out.print(matrix2[i][j].toString() + "\t");
			}
			System.out.println("");
		}
		
		return mergeArray(matrix1, matrix2);
	}

	private static String[][] mergeArray(String[][] m1, String[][] m2) {
		for(int i=0 ; i<m1.length ; i++){
			for(int j=0 ; j<m1[i].length ; j++){
				if("0".equals(m1[i][j]) || "0".equals(m2[i][j])){
					m1[i][j] = "0";
				}
			}
		}
		
		String[][] finalMatrix = new String[7][8];
		
		for(int i=0 ; i<7 ; i++){
			for(int j=0 ; j<8 ; j++){
				finalMatrix[i][j] = m1[i][j];
			}
		}
		
		
		return finalMatrix;
	}
}
