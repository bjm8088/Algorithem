package com.lgcns.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

public class ClientManagerThread extends Thread{

	private Socket m_socket;
	private String m_ID;
	ArrayList<File> fileList;

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();

		BufferedReader in = null;
		PrintWriter out = null;
		int index = 0;
		String strInput = "";
		ArrayList fileLineList = new ArrayList<>();

		try {

			while(true)
			{
				in = new BufferedReader(new InputStreamReader(m_socket.getInputStream()));
				out = new PrintWriter(m_socket.getOutputStream());
				strInput = in.readLine();
				System.out.println("Data�� �����߽��ϴ�." + strInput);

				try {
					index = Integer.parseInt(strInput);
					if(index < fileLineList.size()){
						out.println(fileLineList.get(index).toString());  
						out.flush();
					}else{
						System.out.println("Error : line ��ȣ�� ��ȿ���� �ʽ��ϴ�");
					}
				} catch (Exception e) {

					if("ACK".equals(strInput)){
						index++;
						if(index < fileLineList.size()){
							out.println(fileLineList.get(index).toString());  
							out.flush();
						}
					}else if("ERR".equals(strInput)){
						if(index < fileLineList.size()){
							out.println(fileLineList.get(index).toString());  
							out.flush();
						}
					}else{
						for (File file : fileList) {
							String fileNm = file.getName(); 
							if(fileNm.equals(strInput)){
								fileLineList = encrypt(fileCompress2(fileCompress(fileRead(file))));
							}
						}
						index = 0;

						out.println(fileLineList.get(index).toString());  
						out.flush();
					}
				}
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setSocket(Socket _socket)
	{
		m_socket = _socket;
	}

	public void setFileList(ArrayList<File> _fileList) {
		fileList = new ArrayList<File>();
		fileList = _fileList;
	}
	
	private ArrayList<String> fileRead(File file) throws IOException {

		String line = null;
		ArrayList<String> strList = new ArrayList<String>();

		FileReader fileReader = new FileReader(file.getAbsolutePath());
		BufferedReader bufferedReader = new BufferedReader(fileReader);

		while ((line = bufferedReader.readLine()) != null) {
			//			System.out.println(line);
			strList.add(line);
		}

		return strList;
	}

	/**
	 * ����
	 * @param strList
	 * @return
	 */
	private ArrayList<String> fileCompress(ArrayList<String> strList) {

		ArrayList<String> compStrList = new ArrayList<String>();

		String tempStr = "";

		while(strList.size()>0){
			tempStr = strList.get(0);
			int dupCnt = 0;
			for(int i=0 ; i<strList.size() ; i++){
				if(tempStr.equals(strList.get(i))){
					dupCnt++;
					strList.remove(i);
					i--;
				}
			}
			//System.out.println(dupCnt + "#" + tempStr);
			if(dupCnt > 1){
				tempStr = dupCnt + "#" + tempStr;
			}

			compStrList.add(tempStr);
		}

		System.out.println("����1");
		for(int i=0 ; i<compStrList.size() ; i++){
			//			System.out.println(compStrList.get(i));
		}

		return compStrList;

	}

	private ArrayList<String> fileCompress2(ArrayList<String> strList) {

		ArrayList<String> compStrList = new ArrayList<String>();

		String tempStr = "";

		for(int i=0 ; i<strList.size() ; i++){
			tempStr = strList.get(i);
			String resultStr ="";
			String tStr ="";

			for(int j =0 ; j <tempStr.length() ; j++){
				if(tStr.endsWith(tempStr.charAt(j)+"")){
					tStr = tStr + (tempStr.charAt(j)+"");

					if(j == tempStr.length()-1){
						if(tStr.length() >= 3){
							tStr = tStr.length() + (tStr.charAt(0) +"");
						}
						resultStr = resultStr + tStr;
					}
				}else{
					if(tStr.length() >= 3){
						tStr = tStr.length() + (tStr.charAt(0) +"");
					}
					resultStr = resultStr + tStr;
					tStr = tempStr.charAt(j)+"";
					if(j == tempStr.length()-1){
						resultStr = resultStr + tStr;
					}
				}
			}

			compStrList.add(resultStr);
		}

		System.out.println("����2");
		for(int i=0 ; i<compStrList.size() ; i++){
			//			System.out.println(compStrList.get(i));
		}

		return compStrList;

	}

	private ArrayList<String> encrypt(ArrayList<String> strList) {

		ArrayList<String> compStrList = new ArrayList<String>();

		String tempStr = "";
		char tChar = 0;

		for(int i=0 ; i<strList.size() ; i++){
			tempStr = strList.get(i);
			StringBuffer sb = new StringBuffer();
			for(int j=0 ; j <tempStr.length() ; j++){
				tChar = tempStr.charAt(j);
				if(tChar>= 'F' && tChar <= 'Z'){
					tChar = (char) ((int) tChar - 5);
				}else if(tChar == 'A'){
					tChar = 'V';
				}else if(tChar == 'B'){
					tChar = 'W';
				}else if(tChar == 'C'){
					tChar = 'X';
				}else if(tChar == 'D'){
					tChar = 'Y';
				}else if(tChar == 'E'){
					tChar = 'Z';
				}

				sb.append(tChar);
			}
			compStrList.add(sb.toString());
		}

		System.out.println("������ȣȭ");
		for(int i=0 ; i<compStrList.size() ; i++){
			//			System.out.println(compStrList.get(i));
		}

		return compStrList;

	}

	/**
	 * ���Ͼ��� : ArrayList �� �ִ� ������ ���Ϸ� ����
	 * @param compStrList
	 * @param fileNm
	 * @throws IOException
	 */
	private void fileWriter(ArrayList<String> compStrList, String fileNm) throws IOException {

		// Create Folder
		File destFolder = new File("./OUTPUT");
		if(!destFolder.exists()) {
			destFolder.mkdirs(); 
		} 

		FileWriter fileWriter = new FileWriter("./OUTPUT/" +fileNm);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

		for(int i=0 ; i<compStrList.size() ; i++){
			bufferedWriter.write(compStrList.get(i));
			bufferedWriter.write("\n");
		}

		bufferedWriter.close();

	}
}
