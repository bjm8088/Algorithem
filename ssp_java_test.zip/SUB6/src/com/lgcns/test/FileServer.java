package com.lgcns.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;


public class FileServer {

	static ArrayList<File> fileList = new ArrayList<File>();
	public static ArrayList<BufferedReader> m_InputList;
	public static ArrayList<PrintWriter> m_OutputList;

	public static void main(String[] args) throws IOException {

		File directory = new File("./BIGFILE");
		ArrayList fileLineList = new ArrayList<>();
		scanDirectory(directory);

		ServerSocket listener = null;
		Socket socket = null;

		try {
			listener = new ServerSocket(9876);
		} catch (Exception e) {
			System.out.println("�ش� ��Ʈ�� �����ֽ��ϴ�.");
			listener.close();
		}

		try {
			while (true) {
				System.out.println("������ ��ٸ��ϴ�.");
				socket = listener.accept();
				ClientManagerThread c_thread = new ClientManagerThread();
				c_thread.setSocket(socket);
				c_thread.setFileList(fileList);
				c_thread.start();
			}
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void scanDirectory(File fileHome) {
		String[] contents = fileHome.list();

		for(int i = 0; i < contents.length; i++){	
			File child = new File(fileHome, contents[i]);
			if(child.isDirectory()){
				scanDirectory(child);
			}else if(child.isFile()){
				System.out.println("File_Full_Path : " + child.getAbsolutePath());
				fileList.add(child);
			}
		}
	}
}
