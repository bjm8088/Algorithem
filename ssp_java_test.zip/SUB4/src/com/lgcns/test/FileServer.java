package com.lgcns.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class FileServer {

	static ArrayList<File> fileList = new ArrayList<File>();

	public static void main(String[] args) throws IOException {

		int index = 0;
		String strInput = "";
		File directory = new File("./BIGFILE");
		ArrayList fileLineList = new ArrayList<>();

		BufferedReader in = null;
		PrintWriter out = null;
		ServerSocket listener = null;
		Socket socket = null;

		scanDirectory(directory);

		try {
			listener = new ServerSocket(9876);
		} catch (Exception e) {
			System.out.println("�ش� ��Ʈ�� �����ֽ��ϴ�.");
			listener.close();
		}

		try {
			while (true) {
				System.out.println("������ ��ٸ��ϴ�.");
				if(null == socket) {
					socket = listener.accept();
				}

				try {
					in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
					out = new PrintWriter(socket.getOutputStream());
					strInput = in.readLine();
					System.out.println("Data�� �����߽��ϴ�." + strInput);

					try {
						index = Integer.parseInt(strInput);
						if(index < fileLineList.size()){
							out.println(fileLineList.get(index).toString());  
							out.flush();
						}else{
							System.out.println("Error : line ��ȣ�� ��ȿ���� �ʽ��ϴ�");
						}
					} catch (Exception e) {

						if("ACK".equals(strInput)){
							index++;
							if(index < fileLineList.size()){
								out.println(fileLineList.get(index).toString());  
								out.flush();
							}
						}else if("ERR".equals(strInput)){
							if(index < fileLineList.size()){
								out.println(fileLineList.get(index).toString());  
								out.flush();
							}
						}else{
							for (File file : fileList) {
								String fileNm = file.getName(); 
								if(fileNm.equals(strInput)){
									fileLineList = encrypt(fileCompress2(fileCompress(fileRead(file))));
								}
							}
							index = 0;

							out.println(fileLineList.get(index).toString());  
							out.flush();
						}
					}
				} catch(Exception e){
					socket.close();
				}
			}
		}catch(Exception e){
			socket.close();
			listener.close();
		}
	}

	private static void scanDirectory(File fileHome) {
		String[] contents = fileHome.list();

		for(int i = 0; i < contents.length; i++){	
			File child = new File(fileHome, contents[i]);
			if(child.isDirectory()){
				scanDirectory(child);
			}else if(child.isFile()){
				System.out.println("File_Full_Path : " + child.getAbsolutePath());
				fileList.add(child);
			}
		}
	}

	/**  
	 * �ؽ�Ʈ ������  ���� ������ �о ArrayList�� ��� ����
	 * @param fileNm
	 * @return
	 * @throws IOException
	 */
	private static ArrayList<String> fileRead(File file) throws IOException {

		String line = null;
		ArrayList<String> strList = new ArrayList<String>();

		FileReader fileReader = new FileReader(file.getAbsolutePath());
		BufferedReader bufferedReader = new BufferedReader(fileReader);

		while ((line = bufferedReader.readLine()) != null) {
			//			System.out.println(line);
			strList.add(line);
		}

		return strList;
	}

	/**
	 * ����
	 * @param strList
	 * @return
	 */
	private static ArrayList<String> fileCompress(ArrayList<String> strList) {

		ArrayList<String> compStrList = new ArrayList<String>();

		String tempStr = "";

		while(strList.size()>0){
			tempStr = strList.get(0);
			int dupCnt = 0;
			for(int i=0 ; i<strList.size() ; i++){
				if(tempStr.equals(strList.get(i))){
					dupCnt++;
					strList.remove(i);
					i--;
				}
			}
			//System.out.println(dupCnt + "#" + tempStr);
			if(dupCnt > 1){
				tempStr = dupCnt + "#" + tempStr;
			}

			compStrList.add(tempStr);
		}

		System.out.println("����1");
		for(int i=0 ; i<compStrList.size() ; i++){
			//			System.out.println(compStrList.get(i));
		}

		return compStrList;

	}

	private static ArrayList<String> fileCompress2(ArrayList<String> strList) {

		ArrayList<String> compStrList = new ArrayList<String>();

		String tempStr = "";

		for(int i=0 ; i<strList.size() ; i++){
			tempStr = strList.get(i);
			String resultStr ="";
			String tStr ="";

			for(int j =0 ; j <tempStr.length() ; j++){
				if(tStr.endsWith(tempStr.charAt(j)+"")){
					tStr = tStr + (tempStr.charAt(j)+"");

					if(j == tempStr.length()-1){
						if(tStr.length() >= 3){
							tStr = tStr.length() + (tStr.charAt(0) +"");
						}
						resultStr = resultStr + tStr;
					}
				}else{
					if(tStr.length() >= 3){
						tStr = tStr.length() + (tStr.charAt(0) +"");
					}
					resultStr = resultStr + tStr;
					tStr = tempStr.charAt(j)+"";
					if(j == tempStr.length()-1){
						resultStr = resultStr + tStr;
					}
				}
			}

			compStrList.add(resultStr);
		}

		System.out.println("����2");
		for(int i=0 ; i<compStrList.size() ; i++){
			//			System.out.println(compStrList.get(i));
		}

		return compStrList;

	}

	private static ArrayList<String> encrypt(ArrayList<String> strList) {

		ArrayList<String> compStrList = new ArrayList<String>();

		String tempStr = "";
		char tChar = 0;

		for(int i=0 ; i<strList.size() ; i++){
			tempStr = strList.get(i);
			StringBuffer sb = new StringBuffer();
			for(int j=0 ; j <tempStr.length() ; j++){
				tChar = tempStr.charAt(j);
				if(tChar>= 'F' && tChar <= 'Z'){
					tChar = (char) ((int) tChar - 5);
				}else if(tChar == 'A'){
					tChar = 'V';
				}else if(tChar == 'B'){
					tChar = 'W';
				}else if(tChar == 'C'){
					tChar = 'X';
				}else if(tChar == 'D'){
					tChar = 'Y';
				}else if(tChar == 'E'){
					tChar = 'Z';
				}

				sb.append(tChar);
			}
			compStrList.add(sb.toString());
		}

		System.out.println("������ȣȭ");
		for(int i=0 ; i<compStrList.size() ; i++){
			//			System.out.println(compStrList.get(i));
		}

		return compStrList;

	}

	/**
	 * ���Ͼ��� : ArrayList �� �ִ� ������ ���Ϸ� ����
	 * @param compStrList
	 * @param fileNm
	 * @throws IOException
	 */
	private static void fileWriter(ArrayList<String> compStrList, String fileNm) throws IOException {

		// Create Folder
		File destFolder = new File("./OUTPUT");
		if(!destFolder.exists()) {
			destFolder.mkdirs(); 
		} 

		FileWriter fileWriter = new FileWriter("./OUTPUT/" +fileNm);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

		for(int i=0 ; i<compStrList.size() ; i++){
			bufferedWriter.write(compStrList.get(i));
			bufferedWriter.write("\n");
		}

		bufferedWriter.close();

	}
}
