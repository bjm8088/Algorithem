package com.lgcns.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class FileClient {

	

	public static void main(String[] args) throws IOException {

		String tempStr = "";

		Socket s = null;
		BufferedReader in = null;
		PrintWriter out = null;
		int index = 0;
		
		s = new Socket("127.0.0.1", 9876);
		in = new BufferedReader(new InputStreamReader(s.getInputStream()));
		out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())));
		index = 0;
		int errCnt = 0;
		int rptCnt = 0;
		
		try {
			
			while(true) {
				
				if(index == 0) {
					out.println("ABCDFILE.TXT");                        
					out.flush();
					tempStr = in.readLine();
					
					System.out.println("tempStr : " + tempStr);
					
					if(null != tempStr) {
						System.out.println("ACK");
						out.println("ACK");                        
						out.flush();
						index++;
					}
				}else if(index == 3) {
					tempStr = in.readLine();
					
					System.out.println("tempStr : " + tempStr);
					
					if(null != tempStr) {
						if(errCnt > 3){
							System.out.println(index + "ACK");
							out.println("ACK");                        
							out.flush();
							index++;
						}else{
							System.out.println("ERR");
							out.println("ERR");                        
							out.flush();
							errCnt++;
						}
					}
				}else if(index == 7) {
					tempStr = in.readLine();
					
					System.out.println("tempStr : " + tempStr);
					
					if(null != tempStr) {
						if(rptCnt > 0){
							System.out.println(index + "ACK");
							out.println("ACK");                        
							out.flush();
							index++;
						}else{
							
							System.out.println("2");
							out.println("2");                        
							out.flush();
							rptCnt++;
						}
					}
				}else {
					tempStr = in.readLine();
					System.out.println("tempStr : " + tempStr);
					
					if(null != tempStr) {
						System.out.println(index + "ACK");
						out.println("ACK");                        
						out.flush();
						index++;
					}
				}
			}
		} catch (Exception e) {
			s.close();
		}
	}
}
