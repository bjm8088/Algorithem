package com.lgcns.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class RunManager {

	public static void main(String[] args) throws IOException {
		
		// TODO Auto-generated method stub
		File directory = new File("./BIGFILE");
		File[] fList = directory.listFiles();
		
		Scanner scanner = new Scanner(System.in);
		String strInput = scanner.nextLine();
		String fileNm = "";
			
		for (File file : fList) {
			fileNm = file.getName(); 
        	if(fileNm.equals(strInput)){
        		System.out.println(fileNm+":	"+file.length()+"bytes");
        		fileWriter(fileCompress(fileRead(file.getName())), fileNm);
        	}
        }	
	}

	/**  
	 * �ؽ�Ʈ ������  ���� ������ �о ArrayList�� ��� ����
	 * @param fileNm
	 * @return
	 * @throws IOException
	 */
	private static ArrayList<String> fileRead(String fileNm) throws IOException {
		
		String line = null;
		ArrayList<String> strList = new ArrayList<String>();
		
		FileReader fileReader = new FileReader("./BIGFILE/"+fileNm);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		
		while ((line = bufferedReader.readLine()) != null) {
			System.out.println(line);
			strList.add(line);
		}
		
		return strList;
	}

	/**
	 * ����
	 * @param strList
	 * @return
	 */
	private static ArrayList<String> fileCompress(ArrayList<String> strList) {
		
		ArrayList<String> compStrList = new ArrayList<String>();
		
		String tempStr = "";
		
		while(strList.size()>0){
			tempStr = strList.get(0);
			int dupCnt = 0;
			for(int i=0 ; i<strList.size() ; i++){
				if(tempStr.equals(strList.get(i))){
					dupCnt++;
					strList.remove(i);
					i--;
				}
			}
			//System.out.println(dupCnt + "#" + tempStr);
			if(dupCnt > 1){
				tempStr = dupCnt + "#" + tempStr;
			}
			
			compStrList.add(tempStr);
		}
		
		System.out.println("������");
		for(int i=0 ; i<compStrList.size() ; i++){
			System.out.println(compStrList.get(i));
		}
		
		return compStrList;
		
	}

	/**
	 * ���Ͼ��� : ArrayList �� �ִ� ������ ���Ϸ� ����
	 * @param compStrList
	 * @param fileNm
	 * @throws IOException
	 */
	private static void fileWriter(ArrayList<String> compStrList, String fileNm) throws IOException {
		
		// Create Folder
		File destFolder = new File("./OUTPUT");
		if(!destFolder.exists()) {
			destFolder.mkdirs(); 
		} 
		
		FileWriter fileWriter = new FileWriter("./OUTPUT/" +fileNm);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		
		for(int i=0 ; i<compStrList.size() ; i++){
			bufferedWriter.write(compStrList.get(i));
			bufferedWriter.write("\n");
		}
		
		bufferedWriter.close();
		
	}
}
