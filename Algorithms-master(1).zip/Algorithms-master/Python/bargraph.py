movies = ["Annie Hall","Ben-Hur","Casablanca","Gandhi","West Side Story"]
num_oscars = [5,11,3,8,10]

xs = [i+0.1 for i, _ in enumerate(movies)]

for i in enumerate(movies):
    print(i)
    
    
