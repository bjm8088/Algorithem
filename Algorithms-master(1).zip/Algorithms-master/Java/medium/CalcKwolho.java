package problem10;

public class CalcKwolho {

	public static void main(String[] args) {
		// ((()[[]])([])  == 2 * (2 + 3*3) + 2*3 = 28

	}

}
