package problem8;

public class Galho {

	void calc (String str) {
	    	
	}
	public static void main(String[] args) {
		// [] 4, {} 3, () 2 
		// 감싸면 곱하기
		// 병렬연결은 더하기
		String str = "[{}]()"; //3*4+2
    }

}
