package problem9;

public class Rule3 {
	public static void main (String[]  args) {
		// 다음 기능을 하는 check method 를 만들어라. 
		// 1. 삽입
		//    all, fall  --> true
		// 2. 제거 
		//    fall, all  --> true
		// 3. 대체 
		//    mall, fall --> true
		//    mall, maal --> false
		
	}
}
