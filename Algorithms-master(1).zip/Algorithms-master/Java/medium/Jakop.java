package problem10;

public class Jakop {

	public static void main(String[] args) {
		// 1에서 100 사이수 중에서 제곱 합이 그 수가 되는 수가 있으면 true

	}

}
