package problem9;

public class Brace {

	public static void main(String[] args) {
		// check ("dfdfdf{dfdfdfd(dfd{1111})}") ==> true;
		// check ("     ####{dddd[dddd)  ]555%%%}") ==> false

	}

}
