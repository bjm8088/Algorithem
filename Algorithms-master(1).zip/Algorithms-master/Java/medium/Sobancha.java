package problem9;

public class Sobancha {

	public static void main(String[] args) {
		// sowhajeon = { 10, 20, 30, 60, 100 , 200, 300 };
		// sobancha = { 15, 35, 105 }
		

	}

}
