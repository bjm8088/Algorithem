package problem6;

public class Martial {

	public static void main(String[] args) {
		
	}

}
