package basic;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class DSTest02 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		process("./INPUT/DS_Sample2.csv");
	}

	private static void process(String filePath) throws NumberFormatException, IOException {
		
		Info2 info = new Info2();
		List<Info2> infoList = new ArrayList<Info2>();
		
		List<HashMap<String, String>> infoMapList = new ArrayList<HashMap<String, String>>();
		HashMap<String, String> infoMap = new HashMap<String, String>();
		
		// 1.  ���� �о List �� ���
		FileReader fileReader = new FileReader(filePath);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		
		String readLine = null;
		String[] splitLine = null;
		
		while ((readLine = bufferedReader.readLine()) != null) {
			
//			info = new Info2();
//			info.setMonth(splitLine[0]);
//			info.setId(splitLine[1]);
//			info.setName(splitLine[2]);
//			info.setP1(splitLine[3]);
//			info.setP2(splitLine[4]);
//			info.setP3(splitLine[5]);
//			infoList.add(info);

			infoMap = new HashMap<String, String>();
			splitLine = readLine.split(",");
			infoMap.put("month", splitLine[0]);
			infoMap.put("id", splitLine[1]);
			infoMap.put("name", splitLine[2]);
			infoMap.put("p1", splitLine[3]);
			infoMap.put("p2", splitLine[4]);
			infoMap.put("p3", splitLine[5]);
			infoMapList.add(infoMap);
		}
		
		bufferedReader.close();
		
		System.out.println("List SIZE : " + infoMapList.size());
		
		List idList = new ArrayList<String>();
		String tempId = null;
		
		for(int i=0 ; i<infoMapList.size() ; i++){
			tempId = null;
			tempId = (infoMapList.get(i)).get("id");
			
			if(!idList.contains(tempId)){
				idList.add(tempId);
			}
		}
		
		System.out.println("ID List SIZE : " + idList.size());
		
		List resultList = new ArrayList();
		HashMap sumMap = null;
		
		for(int a = 0 ; a<idList.size() ; a++){
			
			sumMap = new HashMap();
			sumMap.put("id", idList.get(a));
			
			for(int i=0 ; i<infoMapList.size() ; i++){
				
				if(i==0){
					sumMap.put("name", infoMapList.get(i).get("name"));
					sumMap.put("p1", new BigDecimal("0"));
					sumMap.put("p2", new BigDecimal("0"));
					sumMap.put("p3", new BigDecimal("0"));
					sumMap.put("tot", new BigDecimal("0"));
				}
				
				if(idList.get(a).equals(infoMapList.get(i).get("id"))){
					sumMap.put("name", infoMapList.get(i).get("name"));
					sumMap.put("p1", new BigDecimal(sumMap.get("p1").toString()).add(new BigDecimal(infoMapList.get(i).get("p1").toString())));
					sumMap.put("p2", new BigDecimal(sumMap.get("p2").toString()).add(new BigDecimal(infoMapList.get(i).get("p2").toString())));
					sumMap.put("p3", new BigDecimal(sumMap.get("p3").toString()).add(new BigDecimal(infoMapList.get(i).get("p3").toString())));
					sumMap.put("tot", new BigDecimal(sumMap.get("p1").toString()).add(new BigDecimal(sumMap.get("p2").toString())));
					sumMap.put("tot", new BigDecimal(sumMap.get("tot").toString()).add(new BigDecimal(sumMap.get("p3").toString())));
				}
			}
			resultList.add(sumMap);
		}
		
		System.out.println("resultSelt : " + resultList.size());
		
		Map tempMap = null;
		for(int i=0 ; i<resultList.size() ; i++){
			tempMap = new HashMap();
			tempMap = (Map) resultList.get(i);
			
			System.out.print(tempMap.get("id"));
			System.out.print("\t");
			System.out.print(tempMap.get("name"));
			System.out.print("\t");
			System.out.print(tempMap.get("p1"));
			System.out.print("\t");
			System.out.print(tempMap.get("p2"));
			System.out.print("\t");
			System.out.print(tempMap.get("p3"));
			System.out.print("\t");
			System.out.print(" --> ");
			System.out.print(tempMap.get("tot"));
			System.out.print("\n");
		}
	}
}
