package tct.swea.dfs;

import java.util.Stack;

public class S2819 {

	static String[][] matrix = {{"0","1","2","3"}, {"4","5","6","7"}, {"8","9","0","1"}, {"2","3","4","5"}};
	static int[] dx = {-1, 0, 1, 0};
	static int[] dy = {0, 1, 0, -1};
	static int[] visit = new int[10000000];
	static int cnt = 0;
	
	public static void main(String[] args) {
		
		for(int i=0 ; i<4 ; i++){
			for(int j = 0; j < 4; j++) {
				String s = "";
				dfs(i, j, 0, s);
			}
		}

	}

	private static void dfs(int x, int y, int depth, String s) {
		
		if(depth == 6){
			s += matrix[x][y];
			int num = Integer.parseInt(s);
			
			if(visit[num] == 0) {
				visit[num] = 1;
				cnt++;
			}
			
			System.out.println(cnt);
			return;
			
		}else{
			s += matrix[x][y];
			
			for(int i = 0; i < 4; i++) {
				int nx = x + dx[i];
				int ny = y + dy[i];
				
				if(nx >= 0 && ny >= 0 && nx < 4 && ny < 4) {
					dfs(nx, ny, depth+1, s);
				}
			}
		}
	}
}





