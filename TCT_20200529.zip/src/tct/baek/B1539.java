package tct.baek;
import java.util.ArrayList;
import java.util.List;
public class B1539 {

	static int N = 10;
	static Integer[] arrayN = {
			9
			,1
			,4
			,3
			,2
			,5
			,6
			,7
			,8
			,0
	};
	
	public static void main(String[] args) {
		
		int ans = 0;
		BinarySearchTree bst = new BinarySearchTree();
		
		for (int i=0; i<N; i++) {
			ans += bst.add(arrayN[i])+1;
		}
		
		
		System.out.println(ans);
	}
}


