package com.lgcns.tct.list;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Iterator;
import java.util.HashSet;

public class ProductList {
	
	/**
	 * 전체 제품 목록을 구하고, 내림차순으로 정렬하여 반환하는 기능
	 *
	 * @param 	productList1  	List<String>		입력 제품 목록 1
	 * @param 	productList2  	List<String>		입력 제품 목록 2
	 * @return  	       		List<String>		전체 제품 목록 (내림차순 정렬)
	 */
	public List<String> getTotalProductList( List<String> productList1, List<String> productList2 ) {
		
		List<String> result = new ArrayList<String>();
		
		////////////////////////여기부터 코딩 (1) ---------------->
		HashSet<String> list = new HashSet<String>();
		for(String str:productList1) {
			list.add(str);
		}
		for(String str:productList2) {
			list.add(str);
		}
		Iterator<String> it = list.iterator();
		while(it.hasNext()) {
			result.add(it.next());
		}
		result.sort(new AscendingString());
		///////////////////////////// <-------------- 여기까지 코딩 (1)
		
		return result;
	}

	/**
	 * 중복되어 2개 이상 존재하는 제품 목록을 내림차순으로 정렬하여 반환하는 기능
	 *
	 * @param 	productList1  	List<String>		입력 제품 목록 1
	 * @param 	productList2  	List<String>		입력 제품 목록 2
	 * @return  	       		List<String>		중복 제품 목록 (내림차순 정렬)
	 */
	public List<String> getDuplicateProductList( List<String> productList1, List<String> productList2 ) {
		
		List<String> result = new ArrayList<String>();
		
		//////////////////////여기부터 코딩 (2) ---------------->
		HashSet<String> list1 = new HashSet<String>();
		HashSet<String> list2 = new HashSet<String>();
		HashSet<String> list = new HashSet<String>();
		for(String str:productList1) {
			if(list1.contains(str)) {
				list.add(str);
			} else {
				list1.add(str);
			}
		}
		for(String str:productList2) {
			if(list2.contains(str)) {
				if(list.contains(str)) {
					if(!result.contains(str))
						result.add(str);
				}
			} else {
				list2.add(str);
			}
		}
		result.sort(new AscendingString());
		
		///////////////////////////// <-------------- 여기까지 코딩 (2)
		
		return result;
	}
}

class AscendingString implements Comparator<String> { 
	@Override 
	public int compare(String a, String b) { return b.compareTo(a); } 
}
