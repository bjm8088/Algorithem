package com.lgcns.tct.list;

import java.util.Arrays;
import java.util.List;

public class ProductListRun {

    public static void main(String[] args) {
    	
		// 제공 데이터 세트2를 실행하려면 loadData에서 제공 데이터 세트1을 주석 처리하고 제공 데이터 세트2를 주석 해제하여 실행
    	List<List<String>> inputData = loadData();
    	printInput(inputData);
    	
    	List<String> productList1 = inputData.get(0);
    	List<String> productList2 = inputData.get(1);
    	
    	ProductList productList = new ProductList();
    	
    	printResultHeader();
    	
    	// 1. 전체목록 계산
    	List<String> result1 = productList.getTotalProductList( productList1, productList2 );
    	printTotalResult( result1 );
    	
    	// 2.중복목록 계싼
    	List<String> result2 = productList.getDuplicateProductList( productList1, productList2 );
    	printDuplicateResult( result2 );
    }

	private static List<List<String>> loadData() {
		
		//////////////////////////////////
		// 제공 데이터 세트 1
		/////////////////////////////////
		List<List<String>> inputData = Arrays.asList(
				Arrays.asList("냉장고", "에어컨", "공기청정기", "모니터", "냉장고", "모니터"), 
				Arrays.asList("에어컨", "냉장고", "모니터", "컴퓨터", "냉장고", "모니터", "컴퓨터","모니터")
		);
    	
		//////////////////////////////////
		// 제공 데이터 세트 2
		/////////////////////////////////    	
//		List<List<String>> inputData = Arrays.asList(
//				Arrays.asList( "CPU", "RAM", "VGA", "CPU", "HDD", "ODD" ), 
//				Arrays.asList( "MainBoard", "CPU", "ODD", "RAM", "CPU", "RAM", "MainBoard" )
//		);
    	
    	return inputData;
	}

    private static void printInput(List<List<String>> inputData){
    	System.out.println("[초기 입력 데이터]");
    	
    	System.out.print("목록 1 : [");
    	List<String> productList1 = inputData.get(0);
    	for(int i = 0 ; i < productList1.size() ; i++){
    		System.out.print("\"" + productList1.get(i) + "\"");
    		if(i < productList1.size() - 1){
    			System.out.print(", ");
    		}
    	}
    	System.out.println("]");
    	
    	System.out.print("목록 2 : [");
    	List<String> productList2 = inputData.get(1);
    	for(int i = 0 ; i < productList2.size() ; i++){
    		System.out.print("\"" + productList2.get(i) + "\"");
    		if(i < productList2.size() - 1){
    			System.out.print(", ");
    		}
    	}
    	System.out.print("]");
    	
    	System.out.println();
    }
    
    private static void printResultHeader() {
		System.out.println("[전체/중복 목록]");
	}
    
    private static void printTotalResult(List<String> result1) {
    	System.out.print("전체목록 : [");
    	for(int i = 0 ; result1 != null && i < result1.size() ; i++){
    		System.out.print("\"" + result1.get(i) + "\"");
    		if(i < result1.size() - 1){
    			System.out.print(", ");
    		}
    	}
    	System.out.println("]");
	}
	
	private static void printDuplicateResult(List<String> result2) {
		System.out.print("중복목록 : [");
    	for(int i = 0 ; result2 != null && i < result2.size() ; i++){
    		System.out.print("\"" + result2.get(i) + "\"");
    		if(i < result2.size() - 1){
    			System.out.print(", ");
    		}
    	}
    	System.out.println("]");
	}
}