package com.lgcns.tct.sumnumber;

public class SumNumberRun {
	
	public static void main( String[] args ) {
		
		// 제공 데이터 세트2를 실행하려면 loadData에서 제공 데이터 세트1을 주석 처리하고 제공 데이터 세트2를 주석 해제하여 실행
		int[] numbers = loadData();
		
		int startNumber = numbers[0];
		int endNumber   = numbers[1];
		
		printInput( startNumber, endNumber );
		
		SumNumber sumNumber = new SumNumber();
		
		// 1. 각 자리수의 합이 5의 배수인 수들의 개수를 계산하기
		int count = sumNumber.getCharacterNumber( startNumber, endNumber );
		
		printResult( count );
	}
	
	private static int[] loadData() {
    	
		//////////////////////////////////
		// 제공 데이터 세트 1
		/////////////////////////////////
//    	int[] numbers = { 22, 29 };
    	
		//////////////////////////////////
		// 제공 데이터 세트 2
		/////////////////////////////////    	
    	int[] numbers = { 5, 500 };
    	
    	return numbers;
	}
	
	private static void printInput( int startNumber, int endNumber ) {
    	System.out.println( "[입력으로 제공되는 숫자] " + startNumber + " " + endNumber );
    }
    
    private static void printResult( int count ) {
		System.out.println( "[결과] " + count );
	}
}