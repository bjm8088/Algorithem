package com.lgcns.tct.sumnumber;

public class SumNumber {
	
	/**
	 * 각 자리수의 합이 5의 배수인 수들의 개수를 반환하는 기능
	 * 
	 * @param 		startNumber		시작 숫자
	 * @param 		endNumber		마지막 숫자
	 * @return		int				각 자리수의 합이 5의 배수인 수들의 개수
	 */
	public int getCharacterNumber( int startNumber, int endNumber ) {
		
		int count = 0;
		////////////////////////여기부터 코딩 (1) ---------------->
		for(int n=startNumber+1; n<endNumber; n++) {
			int sum = 0;
			int num = n;
			while(num>0) {
				sum += num%10;
				num = num/10;
			}
			if(sum%5==0) count++;
		}
		
		///////////////////////////// <-------------- 여기까지 코딩 (1)
		
		return count;
	}
}