﻿package com.lgcns.tct.position;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Position {
	
	// 열의 크기
	public int COLUMN_SIZE = 5;
	
	/**
	 * 각 직무별 사원번호의 일련번호 오름차순으로 정렬하여 반환하는 기능
	 * 
	 * @param 		employees				초기 데이터
	 * @return		List<List<String>>		직무코드별, 일련번호 순으로 정렬된 데이터
	 */
	public List<List<String>> getSortedEmployees( List<String> employees ) {
		
		List<List<String>> sortedEmployees = new ArrayList<List<String>>();
		
		////////////////////////여기부터 코딩 (1) ---------------->
		List<String> jobs = new ArrayList<String> ();
		for(String str:employees) {
			String job = str.substring(0,2);
			if(jobs.contains(job)) {
				int idx = jobs.indexOf(job);
				(sortedEmployees.get(idx)).add(str);
			} else {
				List<String> newlist = new ArrayList<String>();
				newlist.add(str);
				jobs.add(job);
				sortedEmployees.add(newlist);
			}
		}
		// 동일한 직무코드 안에서 정렬
		for(List<String> list:sortedEmployees) {
			list.sort(new AscendingString());
		}
		// 직무코드 별로 정렬
		int size = jobs.size();
		for(int i=0; i<size-1; i++) {
			int low = i;
			for(int j=size-1; j>i; j--) {
				if(jobs.get(j).compareTo(jobs.get(low))<0) {
					low = j;
				}
			}
			String temp = jobs.get(i);
			jobs.set(i, jobs.get(low));
			jobs.set(low, temp);
			List<String> tlist = sortedEmployees.get(i);
			sortedEmployees.set(i, sortedEmployees.get(low));
			sortedEmployees.set(low, tlist);
		}
		///////////////////////////// <-------------- 여기까지 코딩 (1)
		
		return sortedEmployees;
	}
	
	/**
	 * 특정 사원의 자리의 위치를 찾아 반환해주는 기능
	 * 
	 * @param 		sortedEmployees			사원번호를 직무코드/일련번호 오름차순으로 정렬한 데이터
	 * @param 		employeeNum				사원번호
	 * @return		Map<String, String>		사원의 자리 위치
	 * 										{key: "vertical", value: 문자열(위치)}
	 * 										{key: "horizontal", value: 문자열(위치)}
	 */
	public Map<String, String> findPositionForEmployees( List<List<String>> sortedEmployees, String employeeNum ) {
		
		Map<String, String> position = new HashMap<String, String>();
		
		////////////////////////여기부터 코딩 (2) ---------------->
		int[] sizes = new int[sortedEmployees.size()];
		int[] pos = new int[2];
		int number = 0;
		// 내 위치 찾기
		for(int i=0; i<sizes.length; i++) {
			sizes[i] = sortedEmployees.get(i).size();
		}
		String job = employeeNum.substring(0,2);
		List<String> people = new ArrayList<String> ();
		for(List<String> list : sortedEmployees) {
			String temp = list.get(0).substring(0,2);
			if(job.equals(temp)) {
				pos[0] = sortedEmployees.indexOf(list);
				people = list;
				break;
			}
		}
		pos[1] = people.indexOf(employeeNum);
		// 내가 전부 몇 번째?
		if(pos[1]==-1) {
			position.put("no", "no");
			return position;
		}
		for(int i=0; i<sizes.length; i++) {
			if(sizes[i]<pos[1]) number += sizes[i];
			else {
				if(i<=pos[0]) number += pos[1]+1;
				else number += pos[1];
			}
		}
		// 내 자리 이름
		pos[0] = 'A';
		for(; number>5; number-=5) {
			pos[0]++;
		}
		char[] c = new char[1];
		c[0] = (char)pos[0];
		position.put("horizontal", new String(c));
		if(pos[0]%2==0) {
			position.put("vertical", Integer.toString(6-number));
		} else {
			position.put("vertical", Integer.toString(number));
		}
		///////////////////////////// <-------------- 여기까지 코딩 (2)
		
		return position;
	}
}

class AscendingString implements Comparator<String> { 
	@Override 
	public int compare(String a, String b) { return a.compareTo(b); } 
}