﻿package com.lgcns.tct.position;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class PositionRun {
	
	private static String employeeNum = "";
	
	public static void main( String[] args ) {
		
		// 제공 데이터 세트2를 실행하려면 loadData에서 제공 데이터 세트1을 주석 처리하고 제공 데이터 세트2를 주석 해제하여 실행
		List<String> employees = loadData();
		Position position = new Position();
		
		printInput( employees );
		
		// 1. 각 직무별 사원번호의 일련번호 오름차순으로 정렬하는 기능
		List<List<String>> sortedEmployees = position.getSortedEmployees( employees );
		printSortedData( sortedEmployees );
		
		// 2. 특정 사원의 자리 위치를 찾는 기능
		Map<String, String> searchPosition = position.findPositionForEmployees( sortedEmployees, employeeNum );
		printSearchResult( employeeNum, searchPosition );
	}
	
	private static List<String> loadData() {
    	
		//////////////////////////////////
		// 제공 데이터 세트 1
		/////////////////////////////////
//    	List<String> employees = Arrays.asList(
//    			"AD00006",
//    			"IA00024",
//    			"IA00025",
//    			"AD00004",
//    			"IA00022",
//    			"SP00034",
//    			"AD00002",
//    			"BD00011",
//    			"SP00035",
//    			"AD00007",
//    			"IA00021",
//    			"SP00033",
//    			"SP00032",
//    			"SP00031",
//    			"BD00013",
//    			"BD00012",
//    			"AD00003",
//    			"AD00001",
//    			"IA00023",
//    			"AD00005"
//    	);
//    	employeeNum = "BD00011";
    	
		//////////////////////////////////
		// 제공 데이터 세트 2
		/////////////////////////////////    	
    	List<String> employees = Arrays.asList(
    			"QE66365",
    			"AD72512",
    			"SP53697",
    			"BD72242",
    			"BE21164",
    			"SP69220",
    			"HR73310",
    			"BD60569",
    			"AD73759",
    			"AD71836",
    			"HR72083",
    			"HR80001",
    			"SP75030",
    			"IA60051",
    			"IA67559",
    			"QE50210",
    			"DS80560",
    			"DS72158",
    			"AD72151",
    			"BE68233"
    	);
    	employeeNum = "AD73759";
    	
    	return employees;
	}
	
	private static void printInput( List<String> employees ) {
    	System.out.println( "---------- 초기 입력 데이터 ----------" );
    	for ( String employee : employees ) {
    		System.out.println( "사원번호 : " + employee );
    	}
    	System.out.println();
    }
	
	private static void printSortedData( List<List<String>> sortedEmployees ) {
		System.out.println( "########## 사원 번호 정렬 ##########" );
		for ( List<String> jobEmpList : sortedEmployees ) {
			for ( String employee : jobEmpList ) {
				System.out.println( "사원번호 : " + employee );
			}
		}
		System.out.println();
	}
	
	private static void printSearchResult( String employeeNum, Map<String, String> searchPosition ) {
		System.out.println( "########## 사원 자리 검색 ##########" );
		System.out.println( "사원번호 : " + employeeNum + ", 자리 : { " + searchPosition.get( "horizontal" ) + ", " + searchPosition.get( "vertical" ) + " }" );
	}
}