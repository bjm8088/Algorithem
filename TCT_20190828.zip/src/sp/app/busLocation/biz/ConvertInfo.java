package sp.app.busLocation.biz;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import sp.app.busLocation.util.SortBusLocation;
import sp.app.busLocation.util.SortStationLocation;
import sp.app.busLocation.util.SortStringDesc;
import sp.app.busLocation.vo.BusLocationVo;
import sp.app.busLocation.vo.StationVo;

public class ConvertInfo {

	public static ArrayList<BusLocationVo> convertLocationInfo(ArrayList<String> locationList) {

		ArrayList<BusLocationVo> lastBusLocationList = new ArrayList<BusLocationVo>();

		//1. Sorting : ������ ��ġ�� �������� ����
		Collections.sort(locationList, new SortStringDesc());

		//������ ������ �����ͼ� �Ľ��Ѵ�.
		String[] locationInfo = locationList.get(0).split("#");
		String time =locationInfo[0];
		for(int i=1 ; i<locationInfo.length ; i++) {
			lastBusLocationList.add(new BusLocationVo(time, locationInfo[i].split(",")[0], locationInfo[i].split(",")[1]));
		}

		// Bus ��ġ��� ���� �Ѵ�.(��������)
		Collections.sort(lastBusLocationList, new SortBusLocation());
		
		return lastBusLocationList;
	}
	
	public static ArrayList<StationVo> convertStationInfo(ArrayList<String> stationList) {
		
		ArrayList<StationVo> stationInfoList = new ArrayList<StationVo>();
		for(int i=0 ; i<stationList.size() ; i++) {
			stationInfoList.add(new StationVo(stationList.get(i).split("#")[0], stationList.get(i).split("#")[1]));
		}
		
		// Bus ��ġ��� ���� �Ѵ�.(��������)
		Collections.sort(stationInfoList, new SortStationLocation());
		
		return stationInfoList;
	}
	
	public static HashMap<String, ArrayList<BusLocationVo>> convertLocationInfoMap(ArrayList<String> locationList, String lastTime) {

		HashMap<String, ArrayList<BusLocationVo>> busLocationListMap = new HashMap<>();

		for(int i=0 ; i< locationList.size() ; i++){
			
//			System.out.println(locationList.get(i).toString());
			String[] locationInfo = locationList.get(i).split("#");
			
			String time = locationInfo[0];
			
			if(lastTime.compareTo(locationInfo[0])<1){
				lastTime = locationInfo[0];
			}
			
			for(int j=1 ; j<locationInfo.length ; j++) {
				String key = locationInfo[j].split(",")[0];
				BusLocationVo bus = new BusLocationVo(time, key, locationInfo[j].split(",")[1]);
//				System.out.println("(" + key + ":" + time + ":" + locationInfo[j].split(",")[1]);
				
				if(busLocationListMap.containsKey(key)){
//					System.out.println("Before : " + busLocationListMap.get(key).size());
					(busLocationListMap.get(key)).add(bus);
//					System.out.println("After : " + busLocationListMap.get(key).size());
				}else{
					ArrayList<BusLocationVo> lastBusLocationList = new ArrayList<BusLocationVo>();
					lastBusLocationList.add(bus);
					busLocationListMap.put(key, lastBusLocationList);
//					System.out.println("After : " + busLocationListMap.get(key).size());
				}
			}
		}

		return busLocationListMap;
	}
}
