package sp.app.busLocation.util;

import java.util.Comparator;

import sp.app.busLocation.vo.BusLocationVo;

public class BusLocationSort implements Comparator<BusLocationVo> {

	@Override
	public int compare(BusLocationVo o1, BusLocationVo o2) {
		// TODO Auto-generated method stub
		return o1.getLocation().compareTo(o2.getLocation());
	}

}
