package sp.app.busLocation.util;

import java.util.Comparator;

import sp.app.busLocation.vo.BusLocationVo;

public class SortBusTimeLocation implements Comparator<BusLocationVo> {

	@Override
	public int compare(BusLocationVo o1, BusLocationVo o2) {
		// TODO Auto-generated method stub
		return o1.getTime().compareTo(o2.getTime());
	}

}
