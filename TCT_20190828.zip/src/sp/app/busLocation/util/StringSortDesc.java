package sp.app.busLocation.util;

import java.util.Comparator;

public class StringSortDesc implements Comparator<String>{

	@Override
	public int compare(String s1, String s2) {
		// TODO Auto-generated method stub
		return s1.compareTo(s2);
	}

	
}
