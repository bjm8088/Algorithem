package sp.app.busLocation.util;

import java.util.Comparator;

import sp.app.busLocation.vo.CurrStatusVo;

public class SortCurrStatus implements Comparator<CurrStatusVo> {

	@Override
	public int compare(CurrStatusVo o1, CurrStatusVo o2) {
		// TODO Auto-generated method stub
		return o1.getFutureLocation().compareTo(o2.getFutureLocation());
	}

}
