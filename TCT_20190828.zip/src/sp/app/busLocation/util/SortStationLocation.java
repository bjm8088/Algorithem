package sp.app.busLocation.util;

import java.util.Comparator;

import sp.app.busLocation.vo.StationVo;

public class SortStationLocation implements Comparator<StationVo> {

	@Override
	public int compare(StationVo o1, StationVo o2) {
		// TODO Auto-generated method stub
		return o1.getLocation().compareTo(o2.getLocation());
	}

}
