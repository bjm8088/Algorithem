package sp.app.busLocation.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Utils {

	/**  
	 * �ؽ�Ʈ ������  ���� ������ �о ArrayList�� ��� ����
	 * @param fileNm
	 * @return
	 * @throws IOException
	 */
	public static ArrayList<String> fileRead(File file) throws IOException {
		
		String line = null;
		ArrayList<String> strList = new ArrayList<String>();
		
		FileReader fileReader = new FileReader(file.getAbsolutePath());
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		
		System.out.println("#################################");
		System.out.println("#File contents                  #");
		System.out.println("#################################");
		while ((line = bufferedReader.readLine()) != null) {
			System.out.println(line);
			if(!"PRINT".equals(strList)){
				strList.add(line);
			}
		}
		
		return strList;
	}
	
	public static ArrayList<String> fileRead(String filePath) throws IOException {
		
		String line = null;
		ArrayList<String> strList = new ArrayList<String>();
		
		FileReader fileReader = new FileReader(filePath);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		
		System.out.println("#################################");
		System.out.println("#File contents                  #");
		System.out.println("#################################");
		while ((line = bufferedReader.readLine()) != null) {
			System.out.println(line);
			if(!"PRINT".equals(strList)){
				strList.add(line);
			}
		}
		return strList;
	}
	
	public static void moveFileToBackup(String path, String name) {
		File fileFrom = new File(path); // source
		
		//fileFrom.setWritable(true);
		File dir = new File(".//RCV_BACKUP");
		if(!dir.exists()) {
			dir.mkdirs(); 
		} 
		File fileTo = new File(".//RCV_BACKUP//" + name); // destination
		fileTo.delete();
		fileFrom.renameTo(fileTo);
		
	}
	
	public static void myCopyFile(String path, String name)
	{
		final int BUFFER_SIZE = 512;
        int readLen;
        try {
    		// Create Folder
    		File destFolder = new File(".//RCV_BACKUP");
    		if(!destFolder.exists()) {
    			destFolder.mkdirs(); 
    		}        	
        	
    		// Copy File
            InputStream inputStream = new FileInputStream(path);
            OutputStream outputStream = new FileOutputStream("./RCV_BACKUP/"+name);
 
            byte[] buffer = new byte[BUFFER_SIZE];
 
            while ((readLen = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, readLen);
            }
            
            inputStream.close();
            outputStream.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }		
        
        new File(path).delete();
	}
	
	public static void moveFileToBackup2(String path, String name) throws IOException {
		Path file = Paths.get(path);

		File dir = new File(".//RCV_BACKUP");
		if(!dir.exists()) {
			dir.mkdirs(); 
		} 
		
		Path movePath = Paths.get(".//RCV_BACKUP//");
		Files.move(file , movePath .resolve(file .getFileName()));

	}
	
//	public static void moveFileToBackup3(String path, String name) throws IOException {
//		
//		File file = new File(path);
//
//		File fileToMove = new File(".//RCV_BACKUP//" + name);
//
//		FileUtils.moveDirectoryToDirectory(file, fileToMove,  true);
//
//
//
//	}
	
	public static void fileWriter(ArrayList<String> compStrList, String fileNm) throws IOException {
		
		// Create Folder
		File destFolder = new File("./OUTPUT");
		if(!destFolder.exists()) {
			destFolder.mkdirs(); 
		} 
		
		FileWriter fileWriter = new FileWriter("./OUTPUT/" +fileNm);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		
		System.out.println("#################################");
		System.out.println("#Output File contents           #");
		System.out.println("#################################");
		
		for(int i=0 ; i<compStrList.size() ; i++){
			System.out.println(compStrList.get(i));
			bufferedWriter.write(compStrList.get(i));
			bufferedWriter.write("\n");
		}
		
		bufferedWriter.close();
		
	}
	
	public static String convertPadding(long l, int len) {

		String tempStr = l+"";
		
		if(tempStr.length() < len) {
			int cnt = len - tempStr.length();
			for(int i=0 ; i<cnt ; i++) {
				tempStr = "0" + tempStr;
			}
		}
		return tempStr;
	}
	
	public static String getDistance(String s1, String s2) {
		
		Long l1 = Long.parseLong(s1);
		Long l2 = Long.parseLong(s2);
		
		String result = Utils.convertPadding(l1-l2,5);
		
		return result;
	}

	public static String getRemaindistance(long l1, long l2) {
		
		return Utils.convertPadding(l1 - l2, 5);
	}
	
	public static Long getTimeGap(String lastTime, String currTime) throws ParseException {
		
		System.out.println("lastTime : " + lastTime);
		System.out.println("currTime : " + currTime);
		//HH:MM:SS
		SimpleDateFormat f = new SimpleDateFormat("HH:mm:ss", Locale.KOREA);
		Date d1 = f.parse(lastTime);
		Date d2 = f.parse(currTime);
		long diff = d1.getTime() - d2.getTime();
		long sec = diff/1000;
//		System.out.println("finalTime : " + finalTime);
//		System.out.println("lastTime : " + lastTime);
//		System.out.println("sec : " + sec);
		return sec;
	}
}
