package sp.app.busLocation.util;

import java.util.Comparator;

import sp.app.busLocation.vo.BusLocationVo;

public class SortTimePerBus implements Comparator<BusLocationVo> {

	@Override
	public int compare(BusLocationVo arg0, BusLocationVo arg1) {
		// TODO Auto-generated method stub
		return arg0.getTime().compareTo(arg1.getTime());
	}

}
