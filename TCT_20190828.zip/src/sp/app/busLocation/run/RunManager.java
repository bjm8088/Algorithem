package sp.app.busLocation.run;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import sp.app.busLocation.biz.BusLocationReport;
import sp.app.busLocation.biz.ConvertInfo;
import sp.app.busLocation.util.Utils;
import sp.app.busLocation.vo.BusLocationVo;

public class RunManager {

	public static void main(String[] args) throws IOException {

		// TODO Auto-generated method stub
		File file1 = new File("./INPUT/LOCATION.TXT");
		ArrayList<String> locationList = Utils.fileRead(file1);
		
		ConvertInfo convertInfo = new ConvertInfo();
		ArrayList<BusLocationVo> lastBusLocationList = convertInfo.convertLocationInfo(locationList);
		
		BusLocationReport report = new BusLocationReport();
		ArrayList<String> resultList1 = report.getReportData1(lastBusLocationList);
		
		Utils.fileWriter(resultList1, "RESULT1.TXT");
	}
}
