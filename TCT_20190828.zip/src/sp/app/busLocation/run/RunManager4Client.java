package sp.app.busLocation.run;


import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;

public class RunManager4Client {

	public static void main(String[] args) throws IOException {

		Socket socket = null;
		DataOutputStream os = null;
		try {
			socket = new Socket("127.0.0.1", 27015);
			os = new DataOutputStream(socket.getOutputStream());

			byte[] buffer = new byte[4096];
			int length;

			// get all the files from a directory
			File file = new File("./INPUT/LOCATION.TXT");
			os.writeUTF(file.getName());
			os.writeInt((int) file.length());

			FileInputStream is = null;
			try {
				is = new FileInputStream(file.getPath());
				while ((length = is.read(buffer)) != -1) {
					os.write(buffer, 0, length);
				}
			} finally {
				if (is != null) { is.close(); }
			}

			// move file to backup folder
//			moveFileToBackup(file.getPath(), file.getName());
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (os != null) { os.close(); }
			if (socket != null) { socket.close(); }
		}
	}
}
