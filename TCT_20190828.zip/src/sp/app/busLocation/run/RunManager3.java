package sp.app.busLocation.run;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import sp.app.busLocation.biz.BusLocationReport;
import sp.app.busLocation.biz.ConvertInfo;
import sp.app.busLocation.util.SortCurrStatus;
import sp.app.busLocation.util.SortTimePerBus;
import sp.app.busLocation.util.Utils;
import sp.app.busLocation.vo.BusLocationVo;
import sp.app.busLocation.vo.CurrStatusVo;
import sp.app.busLocation.vo.StationVo;

public class RunManager3 {
	
	static String lastTime = "00:00:00";
	
	public static void main(String[] args) throws IOException, ParseException {

		ArrayList<HashMap<String, Object>> mdata = new ArrayList<HashMap<String,Object>>();
		
		// 1.  ���� �о List of String ���� ���
		File file1 = new File(".//INPUT//LOCATION3.TXT");
//		"..//CLIENT//INSPECTOR.TXT"
		ArrayList<String> locationList = Utils.fileRead(file1);
		
		ConvertInfo convertInfo = new ConvertInfo();
		
		// 2. ���� ������ List �� Map���� ��ȯ
		HashMap<String, ArrayList<BusLocationVo>> busLocationMap = convertLocationInfoMap(locationList);
		
		// 3. Map �� Value �� List�� ����
		busLocationMap = sortListInMap(busLocationMap);

		// 4. Bus ���� ��� (������ġ, �����ӵ�)
		ArrayList<CurrStatusVo> CurrStatusList = getFinalStatus(busLocationMap);
		
		// 5. ������ ���� �ִ� �ӵ� �����ؼ� ������ġ ���ϱ�
		CurrStatusList = getFutureStatus(CurrStatusList);
		Collections.sort(CurrStatusList, new SortCurrStatus());
		printCurrStatus(CurrStatusList);
			
		// 6. ������ �ҷ�����
		File file2 = new File("./INPUT/STATION.TXT");
		ArrayList<String> stationList = Utils.fileRead(file2);
		ArrayList<StationVo> stationLocationList = convertInfo.convertStationInfo(stationList);
		
		// 7. ���� ������������ �ȳ� ���
		BusLocationReport report = new BusLocationReport();
		ArrayList<String> resultList2 = report.getReportData3(CurrStatusList,stationLocationList);
		Utils.fileWriter(resultList2, "RESULT3.TXT");
		
	}
	
	private static ArrayList<CurrStatusVo> getFutureStatus(ArrayList<CurrStatusVo> inputList) throws ParseException {
		for(int i=0 ; i<inputList.size() ; i++){
			Long timeGap = Utils.getTimeGap(lastTime, inputList.get(i).getTime());
			Long futureLocation = timeGap * inputList.get(i).getSpeed() + Long.parseLong(inputList.get(i).getLocation());
			inputList.get(i).setFutureLocation(Utils.convertPadding(futureLocation, 5));
		}
		
		return inputList;
	}

	private static void printCurrStatus(ArrayList<CurrStatusVo> currStatusList) {

		for(int i=0 ; i<currStatusList.size() ; i++){
			System.out.println("============================");
			System.out.println("BUS_ID : " + currStatusList.get(i).getBusId());
			System.out.println("FINAL_TIME : " + currStatusList.get(i).getTime());
			System.out.println("LAST_TIME : " + lastTime);
			System.out.println("FINAL_LOCATION : " + currStatusList.get(i).getLocation());
			System.out.println("FINAL_SPEED : " + currStatusList.get(i).getSpeed());
			System.out.println("Future_LOCATION : " + currStatusList.get(i).getFutureLocation());
		}
	}

	private static ArrayList<CurrStatusVo> getFinalStatus(HashMap<String, ArrayList<BusLocationVo>> inputMap) throws ParseException {
		
		ArrayList<CurrStatusVo> calResult = new ArrayList<CurrStatusVo>();
		
		//1.keySet�� �����´�.
		Set<String> keys = inputMap.keySet();
		Iterator it = keys.iterator();

		while(it.hasNext()){
			calResult.add(calBus(inputMap.get(it.next())));
		}
		return calResult;
	}

	private static CurrStatusVo calBus(ArrayList<BusLocationVo> inputList) throws ParseException {
		String id = "";
		int totDist = 0;
		int finalSpeed = 0;
		String finalLocation = "";
		String prevLocation = "";
		String finalTime ="";
		Long timeGap;
		
		for(int i=0 ; i<inputList.size() ; i++){
			if(i==0){
				id = inputList.get(i).getBusId();
				finalTime =  inputList.get(i).getTime();
				finalLocation =  inputList.get(i).getLocation();
				prevLocation = inputList.get(i).getLocation();
				totDist = Integer.parseInt(finalLocation) - Integer.parseInt(prevLocation);
				finalSpeed = 0;
				timeGap = Utils.getTimeGap(lastTime,finalTime);
			}else{
				finalTime =  inputList.get(i).getTime();
				finalLocation =  inputList.get(i).getLocation();
				prevLocation = inputList.get(i-1).getLocation();
				totDist = (Integer.parseInt(finalLocation) - Integer.parseInt(prevLocation)) + totDist;
				finalSpeed = Integer.parseInt(finalLocation) - Integer.parseInt(prevLocation);
				timeGap = Utils.getTimeGap(lastTime,finalTime);
				
			}
		}
		
		CurrStatusVo currStatus = new CurrStatusVo(finalTime, id, finalLocation, finalSpeed);
		return currStatus;
	}

	private static void print(ArrayList<List> busAllLocationList) {
		
//		System.out.println("busAllLocationList : " + busAllLocationList.size());
		for(int i=0 ; i<busAllLocationList.size() ;i++){
			ArrayList busLocationList = (ArrayList) busAllLocationList.get(i); 
//			System.out.println("busLocationList : " + busLocationList.size());
			for(int j=0 ; j<busLocationList.size() ; j++){
				BusLocationVo busLocation = (BusLocationVo) busLocationList.get(i);
				System.out.println("==================================");
				System.out.println("BUS_ID : " + ((BusLocationVo)busLocationList.get(j)).getBusId());
				System.out.println("Time : " + ((BusLocationVo)busLocationList.get(j)).getTime());
				System.out.println("BUS_Location : " + ((BusLocationVo)busLocationList.get(j)).getLocation());
			}
		}
	}

	private static HashMap<String, ArrayList<BusLocationVo>> sortListInMap(HashMap<String, ArrayList<BusLocationVo>> inputMap) {
		
		//1.keySet�� �����´�.
		Set<String> keys = inputMap.keySet();
		Iterator it = keys.iterator();
				
		while(it.hasNext()){
			Collections.sort(inputMap.get(it.next()), new SortTimePerBus()); //Bus Location ������Ʈ�� �����Ǿ� �ִ� List�� ����
		}
		
		return inputMap;
	}

	private static ArrayList<List> sortMap(HashMap<String, ArrayList<BusLocationVo>> busLocationMap) {
		
		ArrayList<List> busAllLocationList = new ArrayList<List>();
		
		//1.keySet�� �����´�.
		Set<String> keys = busLocationMap.keySet();
		Iterator it = keys.iterator();
		
		//2. ������ KeySet �� List ���·� ��´�.
		ArrayList<String> keyList = new ArrayList<String>();
		
		while(it.hasNext()){
			keyList.add(it.next() + "");
		}
		
		//3. Key ������ �����Ѵ�.
		Collections.sort(keyList);
		
		//4. ������ Ű������ �ʿ��� Value�� �̾� List �� ��´�.(��� : Ű�� ������Ʈ ����Ʈ�� ����)
		for(int i = 0 ; i<keyList.size() ; i++){
			busAllLocationList.add(busLocationMap.get(keyList.get(i)));
		}
		
		// Key �� �������� ���ĵ� ����Ʈ�� ����Ʈ�� ��ȯ
		return busAllLocationList;
	}
	
	public static HashMap<String, ArrayList<BusLocationVo>> convertLocationInfoMap(ArrayList<String> locationList) {

		HashMap<String, ArrayList<BusLocationVo>> busLocationListMap = new HashMap<>();

		for(int i=0 ; i< locationList.size() ; i++){
			
//			System.out.println(locationList.get(i).toString());
			String[] locationInfo = locationList.get(i).split("#");
			
			String time = locationInfo[0];
			
			if(lastTime.compareTo(locationInfo[0])<1){
				lastTime = locationInfo[0];
			}
			
			for(int j=1 ; j<locationInfo.length ; j++) {
				String key = locationInfo[j].split(",")[0];
				BusLocationVo bus = new BusLocationVo(time, key, locationInfo[j].split(",")[1]);
//				System.out.println("(" + key + ":" + time + ":" + locationInfo[j].split(",")[1]);
				
				if(busLocationListMap.containsKey(key)){
//					System.out.println("Before : " + busLocationListMap.get(key).size());
					(busLocationListMap.get(key)).add(bus);
//					System.out.println("After : " + busLocationListMap.get(key).size());
				}else{
					ArrayList<BusLocationVo> lastBusLocationList = new ArrayList<BusLocationVo>();
					lastBusLocationList.add(bus);
					busLocationListMap.put(key, lastBusLocationList);
//					System.out.println("After : " + busLocationListMap.get(key).size());
				}
			}
		}

		return busLocationListMap;
	}

	
}
