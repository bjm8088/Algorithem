package sp.app.busLocation.run;

import java.io.File;
import java.io.IOException;

import sp.app.busLocation.util.Utils;

public class Test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File(".//RCV//LOCATION.TXT");
		
//		Utils.moveFileToBackup2(file.getPath(), file.getName());
		
		file.delete();
	}

}
