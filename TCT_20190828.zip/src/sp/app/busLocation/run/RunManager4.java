package sp.app.busLocation.run;

import java.io.IOException;
import java.text.ParseException;

import sp.app.busLocation.biz.CollectionServer;
import sp.app.busLocation.biz.FileAnalyzer;

public class RunManager4 {
	
	/*
	 * HashMap<String, ArrayList<BusLocation>>
	 * ArrayList<ArrayList<BusLocation>>
	 * 
	 * 
	 */

	public static void main(String[] args) throws IOException, ParseException {

		CollectionServer collectionServer = new CollectionServer();
		Thread thread1 = new Thread(collectionServer);
		thread1.start();
		
		FileAnalyzer fileAnalyzer = new FileAnalyzer();
		Thread thread2 = new Thread(fileAnalyzer);
		thread2.start();
		
		
	}
}
