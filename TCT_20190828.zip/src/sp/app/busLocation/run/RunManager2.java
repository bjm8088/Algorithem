package sp.app.busLocation.run;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import sp.app.busLocation.biz.BusLocationReport;
import sp.app.busLocation.biz.ConvertInfo;
import sp.app.busLocation.util.Utils;
import sp.app.busLocation.vo.BusLocationVo;
import sp.app.busLocation.vo.StationVo;

public class RunManager2 {

	public static void main(String[] args) throws IOException {

		// TODO Auto-generated method stub
		File file1 = new File("./INPUT/LOCATION2.TXT");
		ArrayList<String> locationList = Utils.fileRead(file1);

		File file2 = new File("./INPUT/STATION.TXT");
		ArrayList<String> stationList = Utils.fileRead(file2);
		
		ConvertInfo convertInfo = new ConvertInfo();
		ArrayList<BusLocationVo> lastBusLocationList = convertInfo.convertLocationInfo(locationList);
		ArrayList<StationVo> stationLocationList = convertInfo.convertStationInfo(stationList);
		
		BusLocationReport report = new BusLocationReport();
		ArrayList<String> resultList = report.getReportData2(lastBusLocationList,stationLocationList);
		
		Utils.fileWriter(resultList, "RESULT2.TXT");
	}

}
