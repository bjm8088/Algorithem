package sp.app.busLocation.vo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import sp.app.busLocation.util.Utils;


public class BusClientVo {

	

	public static void main(String[] args) throws IOException {

		// 1.  ���� �о List of String ���� ���
		File file1 = new File("./INPUT/LOCATION4.TXT");
		ArrayList<String> locationList = Utils.fileRead(file1);
				
		Socket s = null;
		PrintWriter out = null;
		
		s = new Socket("127.0.0.1", 9876);
		out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())));
		
		try {
			
			for(int i=0; i<locationList.size() ; i++) {
				out.println(locationList.get(i));
				out.flush();
				Thread.sleep(10000);
			}
			
		} catch (Exception e) {
			s.close();
		}
	}
}
