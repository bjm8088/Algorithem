package sp.app.busLocation.vo;

public class BusLocationVo {
	
	String time;
	String busId;
	String location;
	
	public BusLocationVo(String time2, String string, String string2) {
		// TODO Auto-generated constructor stub
		setTime(time2);
		setBusId(string);
		setLocation(string2);
	}
	public String getBusId() {
		return busId;
	}
	public void setBusId(String busId) {
		this.busId = busId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	
	
}
