package sp.app.busLocation.vo;

public class CurrStatusVo {
	
	String time;
	String busId;
	String location;
	String futureLocation;
	int speed;
	
	
	public CurrStatusVo(String time2, String string, String string2) {
		// TODO Auto-generated constructor stub
		setTime(time2);
		setBusId(string);
		setLocation(string2);
	}
	public CurrStatusVo(String time2, String string, String string2, int intVal) {
		// TODO Auto-generated constructor stub
		setTime(time2);
		setBusId(string);
		setLocation(string2);
		setSpeed(intVal);
	}
	public String getBusId() {
		return busId;
	}
	public void setBusId(String busId) {
		this.busId = busId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getFutureLocation() {
		return futureLocation;
	}
	public void setFutureLocation(String futureLocation) {
		this.futureLocation = futureLocation;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	
	
}
