package sp.app.busLocation.vo;

public class StationVo {
	
	String stationId;
	String location;
	String limitSpeed;
	
	public StationVo(String string, String string2) {
		// TODO Auto-generated constructor stub
		setStationId(string);
		setLocation(string2);
	}
	
	public StationVo(String string, String string2, String string3) {
		// TODO Auto-generated constructor stub
		setStationId(string);
		setLocation(string2);
		setLimitSpeed(string3);
	}

	public String getStationId() {
		return stationId;
	}

	public void setStationId(String stationId) {
		this.stationId = stationId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLimitSpeed() {
		return limitSpeed;
	}

	public void setLimitSpeed(String limitSpeed) {
		this.limitSpeed = limitSpeed;
	}
	
	
	
	
}
