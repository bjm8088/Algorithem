package lang.java201905;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class EX_02_removedup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] inputData = {"mail", "bbs", "planner", "mail", "mywork", "planner", "mail", "collab"};
//		String inputData = "abc";
		
		function(inputData);
//		System.out.println("Answer : " + answer);
	}

	private static void function(String[] inputData) {
		
		String temp;
		char basic = 0;
		String result ="";
		int cnt = 0;
		
		Map map = new HashMap<>();
		List list = new ArrayList<>();
		
		for(int i=0 ; i<inputData.length ; i++){
			
			temp = inputData[i];
			if(!list.contains(temp)){
				
				list.add(temp);
				cnt = 0;
				for(int j=0 ; j<inputData.length ; j++){
					if(temp.equals(inputData[j])){
						cnt++;
					}
				}
				
				System.out.println(temp + " : " + cnt);
			}
				
			if(map.containsKey(inputData[i])){
				map.put(inputData[i], Integer.parseInt(map.get(inputData[i])+"")+1+"");
			}else{
				map.put(inputData[i], 1+"");
			}
		}
		
		
		System.out.println(map.toString());
		
		Iterator it = map.entrySet().iterator();
		while (it.hasNext()) {
			String key = it.next().toString();
			System.out.println("entrySet : " + key);
		}
		
		Iterator itk = map.keySet().iterator();
		while (itk.hasNext()) {
			String key = itk.next().toString();
			System.out.println("KEY : " + key);
			System.out.println("VALUE : " + map.get(key));
		}
		
		System.out.println("KEY_SET : " + map.keySet().toString());
		System.out.println("Map_VALUE : " + map.values().toString());
		System.out.println("List : " + list.toString());
	}
}
