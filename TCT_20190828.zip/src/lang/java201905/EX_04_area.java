package lang.java201905;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lang.java201905.EX_03_musicbox.Bell;

public class EX_04_area {

	static List<List> areaGroupList = new ArrayList<List>();
	static int min;
	static int max;
	
	public static void main(String[] args) {

		int[] inputArray = {0,6};
		Integer[][] matrix = {  {0, 0, 0, 0, 0, 0, 1},
								{1, 0, 0, 0, 1, 1, 1},
								{1, 1, 0, 0, 1, 0, 0},
								{0, 0, 0, 0, 0, 0, 0},
								{0, 0, 0, 1, 1, 1, 0},
								{0, 0, 0, 1, 0, 1, 0},
								{0, 0, 0, 0, 0, 0, 0}};

		function(matrix, inputArray);
		
		displayResult();
		
	}

	private static void function(Integer[][] matrix, int[] inputArray) {
		
		min = inputArray[0];
		max = inputArray[1];
		
		List<Area> areaList = new ArrayList<Area>();
		
		// ���� 1�� element �� List �� ��´�.
		for(int i=0 ; i<matrix.length ; i++) {
			for(int j=0 ; j<matrix[i].length ; j++) {
				if(1 == matrix[i][j]) {
					Area area = new Area();
					area.setPosX(j);
					area.setPosY(i);
					areaList.add(area);
				}
			}
		}
		
		for(int i=0 ; i< areaList.size() ; i++) {
			
			//1. ���� �ִ� �׷��� �ִ��� ã�´�.
			int groupIndex = findGroup(areaList.get(i));
			
			//2. ���� �ִ� �׷��� ������ �űԵ�� �Ѵ�.
			if(groupIndex<0){
				newGroup(areaList.get(i));
				groupIndex = findGroup(areaList.get(i));
			}
			
			//3. ��, ��, ��, �� ��ǥ�� ���Ѵ�.
			int currPosX = areaList.get(i).getPosX();
			int currPosY = areaList.get(i).getPosY();
			
			int[][] pos = {{currPosX, currPosY-1},{currPosX, currPosY+1},{currPosX+1, currPosY},{currPosX-1, currPosY}};
			
			//4. �����¿� ��ǥ��, ��ǥ�� ��ȿ����, ���� 1�ΰ͸� ��󳽴�.
			int[][] validPos = isValidPos(matrix,pos);
			
			//5. �����¿��� ��ǥ���� �׷쿡 ����� �Ǿ� �ִ��� Ȯ���Ѵ�.������, ���ر׷��� �׷쿡 �߰��Ѵ�.
			int tGroupId = -1;
			Area tArea;
			for(int a=0 ; a<validPos.length ; a++){
				tGroupId = -1;
				tArea = new Area();
				tArea.setPosX(validPos[a][0]);
				tArea.setPosY(validPos[a][1]);
				tGroupId = findGroup(tArea);
				
				if(tGroupId<0){
					addAreaGroup(tArea,groupIndex);
				}
			}
		}
		
		List<List> resultList = new ArrayList<>();
		
//		while(areaGroupList.size()>0){
//			List<Area> tGroup = (List<Area>) areaGroupList.get(0);
//			List<Area> resultGroup = new ArrayList<Area>();
//			
//			for(int c=0 ; c<tGroup.size() ; c++){
//				resultGroup.add((Area) tGroup.get(c));
//			}
//			
//			int tP = -1;
//			
//			for(int j=0 ; j<tGroup.size() ; j++){
//				int currPosX = tGroup.get(j).getPosX();
//				int currPosY = tGroup.get(j).getPosY();
//				
//				int[][] pos = {{currPosX, currPosY-1},{currPosX, currPosY+1},{currPosX+1, currPosY},{currPosX-1, currPosY}};
//				
//				for(int a=0 ; a<pos.length ; a++){
//					Area tA = new Area();
//					tA.setPosX(pos[a][0]);
//					tA.setPosY(pos[a][1]);
//					tP = findGroup2(tA, 0);
//					
//					if( tP >= 0){
//						break;
//					}
//				}
//				
//				if( tP >= 0){
//					for(int c=0 ; c<areaGroupList.get(tP).size() ; c++){
//						resultGroup.add((Area) areaGroupList.get(tP).get(c));
//					}
//					areaGroupList.remove(tP);
//					break;
//				}
//			}
//			resultList.add(resultGroup);
//			areaGroupList.remove(0);
//		}
	}
	
	private static void addAreaGroup(Area tArea, int groupIndex) {
		((List<Area>) areaGroupList.get(groupIndex)).add(tArea);
	}

	private static int[][] isValidPos(Integer[][] matrix, int[][] pos) {
		
		int valCnt =0;
		for(int a=0 ; a<pos.length ; a++){
			if(pos[a][0] >= min && pos[a][0] <= max && pos[a][1] >= min && pos[a][1] <= max){
				if(1 == matrix[pos[a][1]][pos[a][0]]){
					valCnt++;
				}
			}
		}
		
		int[][] validPos = new int[valCnt][2];
		int x = 0 ;
		for(int a=0 ; a<pos.length ; a++){
			if(pos[a][0] >= min && pos[a][0] <= max && pos[a][1] >= min && pos[a][1] <= max){
				if(1 == matrix[pos[a][1]][pos[a][0]]){
					validPos[x][0] = pos[a][0];
					validPos[x][1] = pos[a][1];
					x++;
					
				}
			}
		}
		
		return validPos;
	}

	private static void newGroup(Area area) {
		List<Area> newAreaGroup = new ArrayList<Area>();
		newAreaGroup.add(area);
		areaGroupList.add(newAreaGroup);
	}

	private static int findGroup(Area area) {
		int grId = -1;
		
		for(int i =0 ; i<areaGroupList.size() ; i++){
			List<Area> tGroup = (List<Area>) areaGroupList.get(i);
			for(int j=0 ; j <tGroup.size() ; j++){
				if(area.getPosX() == tGroup.get(j).getPosX() && area.getPosY() == tGroup.get(j).getPosY()){
					grId = i;
				}
			}
		}
		return grId;
	}
	
	private static int findGroup2(Area area, int me) {
		int grId = -1;
		
		for(int i =0 ; i<areaGroupList.size() ; i++){
			if(i!=me){
				List<Area> tGroup = (List<Area>) areaGroupList.get(i);
				for(int j=0 ; j <tGroup.size() ; j++){
					if(area.getPosX() == tGroup.get(j).getPosX() && area.getPosY() == tGroup.get(j).getPosY()){
						grId = i;
					}
				}	
			}
		}
		return grId;
	}
	
	static class Area{
		int posX;
		int posY;
		public int getPosX() {
			return posX;
		}
		public void setPosX(int posX) {
			this.posX = posX;
		}
		public int getPosY() {
			return posY;
		}
		public void setPosY(int posY) {
			this.posY = posY;
		}
	}
	
	private static void displayResult() {
		int areaGroupCnt = areaGroupList.size();
		List<Integer> resultList = new ArrayList<Integer>();
		
		for(int i=0 ; i<areaGroupCnt ; i++){
			List<Area> tGroup = (List<Area>) areaGroupList.get(i);
			resultList.add(i,tGroup.size());
			System.out.println(i + "��° area : " + tGroup.size());
			for(int j=0 ; j<tGroup.size() ; j++){
				System.out.println("(" + tGroup.get(j).getPosX() + " , " + tGroup.get(j).getPosY() + ")");
				
			}
		}
	}
}

