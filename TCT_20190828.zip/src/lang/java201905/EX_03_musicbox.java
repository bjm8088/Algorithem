package lang.java201905;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class EX_03_musicbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] inputData = {
				{"C", "1", "1", "2", "3"},
				{"G", "3", "8", "3"},
				{"B", "9", "3", "1"},
				{"D", "4", "3", "1", "3", "2"},
				{"E", "5"},
				{"A", "6", "1", "5", "1"},
				{"F", "4", "2", "2"}
		};

		//		String inputData = "abc";

		String result1 = function_map(inputData);
		System.out.println("Answer1 : " + result1);
		
		List result2 = function_list(inputData);
		
		for(int i=0 ; i<result2.size() ; i++){
			System.out.println("NAME : " + ((Bell) result2.get(i)).getBellNm() + ", LAST ON : " + ((Bell) result2.get(i)).getLastOn());
		}
		
		List result3 = function_harmony(inputData);
		
		System.out.println("answer3 : " + result3.toString());
		
	}



	private static List function_harmony(String[][] inputData) {
		String lastOnNm = function_map(inputData);
		int maxTurn = 14;
		int len = 0;
		int lastTime = 0;
		String nm = "";
		String harmony ="";
		List<String> harmonyList = new ArrayList<String>();
		
		for(int i=1 ; i<=maxTurn ; i++){
			harmony ="";
			for(int j=0 ; j<inputData.length ; j++){
				lastTime = 0;
				len = inputData[j].length;
				nm = inputData[j][0];
				
				for(int k=1 ; k <len ; k++){
					lastTime = lastTime + Integer.parseInt(inputData[j][k]);
					if(i == lastTime){
						harmony = harmony + nm;
					}
				}
			}
			harmonyList.add(harmony);
		}
		
		return harmonyList;
	}



	private static String function_map(String[][] inputData) {

		String last = "";
		int tt = 0;
		int len = 0;
		Map map = new HashMap<>();

		// map data ����
		for(int i=0 ; i<inputData.length ; i++){
			tt = 0;
			len = inputData[i].length;
			last = inputData[i][0];
			for(int j=2 ; j <len ; j++){
				tt = tt + Integer.parseInt(inputData[i][j]);
			}
			map.put(inputData[i][0], Integer.parseInt(inputData[i][1]) + tt);
		}

		// map �߿� max ���ϱ�
		String maxKey = "";
		int maxCnt = 0;

		Iterator itk = map.keySet().iterator();
		while (itk.hasNext()) {
			String key = itk.next().toString();

			System.out.println("KEY : " + key);
			System.out.println("VALUE : " + map.get(key));

			if(maxCnt<Integer.parseInt(map.get(key).toString())){
				maxCnt = Integer.parseInt(map.get(key).toString());
				maxKey = key;
			}
		}

		System.out.println(maxKey + " : " + map.get(maxKey));
		
		return maxKey;
	}
	
	private static List function_list(String[][] inputData) {

		int len = 0;
		int lastOn = 0;

		// list data �����ؼ� max

		Bell bell = null;
		List<Bell> bellList = new ArrayList<Bell>();

		for(int i=0 ; i<inputData.length ; i++){

			lastOn = 0;
			len = inputData[i].length;
			
			for(int j=2 ; j <len ; j++){
				lastOn = lastOn + Integer.parseInt(inputData[i][j]);
			}

			bell = new Bell();
			bell.setBellNm(inputData[i][0]);
			bell.setInit(Integer.parseInt(inputData[i][1]));
			bell.setLastOn(Integer.parseInt(inputData[i][1]) + lastOn);
			
			bellList.add(bell);
		}
		
		Collections.sort(bellList, new Comparator<Bell>() { 

			@Override
			public int compare(Bell o1, Bell o2) {
				if(o1.lastOn < o2.lastOn){ //��������
					return 1;
				}else if(o1.lastOn > o2.lastOn){
					return -1;
				}else{
					return 0;
				}
			}
		});
		
		return bellList;
	}

	public static class Bell {
		String bellNm;
		int init;
		int lastOn;
		public String getBellNm() {
			return bellNm;
		}
		public void setBellNm(String bellNm) {
			this.bellNm = bellNm;
		}
		public int getInit() {
			return init;
		}
		public void setInit(int init) {
			this.init = init;
		}
		public int getLastOn() {
			return lastOn;
		}
		public void setLastOn(int lastOn) {
			this.lastOn = lastOn;
		}
	}
}


