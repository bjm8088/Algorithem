package lang.java201906;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EXE_03_cardset {

	static int[] triple_carddeck = {  1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
			1, 2, 9, 8, 3, 4, 7, 6, 10, 5,
			5, 3, 2, 4, 1, 6, 7, 8, 9, 10};

	public static void main(String[] args) {

		//���,�⵵,���
		int[][] inputData = {{7,9},{5,7}};
		List<Integer> result = function(inputData);
		for(int i=0 ; i<result.size() ; i++){
			System.out.print(result.get(i) + "\t");
		}
		System.out.println("");
	}

	private static List<Integer> function(int[][] inputData) {
		
		List<Integer> cardList = new ArrayList<Integer>();
		for(int i = 0 ; i<triple_carddeck.length ; i++){
			cardList.add(i,triple_carddeck[i]);
		}
		
		List<Integer> removeList = null;
		
		for(int a=0 ; a<inputData.length ; a++){
			
			removeList = new ArrayList<Integer>();
			int begin = inputData[a][0];
			int end = inputData[a][1];
			
			// ����
			for(int i = begin ; i <= end ; i++){
				removeList.add(cardList.get(i));
				cardList.remove(i-1);
			}
			
			// ������ �ֱ�
			for(int i = 0 ; i<removeList.size() ; i++){
				cardList.add(removeList.get(i));
			}
		}
		
		List<Integer> cardList1 = null;
		List<Integer> cardList2 = null;
		List<Integer> cardList3 = null;
		
		for(int a=0 ; a<cardList.size() ; a++){
			cardList1 = new ArrayList<Integer>();
			cardList2 = new ArrayList<Integer>();
			cardList3 = new ArrayList<Integer>();
			
			switch(a%3){
				case 0 : cardList1.add(cardList.get(a));break;
				case 1 : cardList2.add(cardList.get(a));break;
				case 2 : cardList3.add(cardList.get(a));break;
				default:break;
			}
		}
		
		Collections.sort(cardList3);
		
		return cardList3;
	}

}
