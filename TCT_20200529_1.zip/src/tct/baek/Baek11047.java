package tct.baek;
import java.util.Arrays;

public class Baek11047 {

	public static void main(String[] args) {
		int n = 10;
		int k= 4200;
		int coins[] = {
		1
		,5
		,10
		,50
		,100
		,500
		,1000
		,5000
		,10000
		,50000};
		
		int[] result = new int[10];
		int max = 0;
		int maxIdx = 0;
		
		Arrays.sort(coins);
		
		for(int i=0 ; i<coins.length ; i++){
			if(coins[i] > max && coins[i] <=k) {
				max = coins[i];
				maxIdx = i;
			}
		}
		
		int coinValue = 0;
		int coinCount = 0;
		
		for(int a = maxIdx ; a >= 0 ; a--){
			
			int tempValue = coins[a];
			
			while (coinValue + tempValue <= k){
				coinValue = coinValue + tempValue;
				result[a]++;
				coinCount++;
			}
			
		}
		
		System.out.println("COINS COUNT : " + coinCount);
	}
	
	
}
