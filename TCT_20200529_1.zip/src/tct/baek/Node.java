package tct.baek;
public class Node {
	
	int data;
    Node left;
	Node right;

    public Node(int data) {
        this.data = data;
        left = right = null;
    }

    int compareTo(Node node) {
    	
    	int result = 0;
    	if(this.data>node.data) result = 1;
    	else if(this.data<node.data) result = -1;
    	else if(this.data==node.data) result =  0;
    	
    	return result;
    }

}
