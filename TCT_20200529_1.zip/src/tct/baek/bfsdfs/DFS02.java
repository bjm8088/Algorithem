package tct.baek.bfsdfs;
import java.util.ArrayList;
import java.util.List;

public class DFS02 {

	public static void main(String[] args) {
		String[] words = {"hot","dot","dog","lot","log","cog"};
		String begin = "hit";
		String target = "cog";

		int result = solution(begin, target, words);

		System.out.println("answer : " + result);

	}

	public static int solution(String begin, String target, String[] words) {
        int answer = 0;
        boolean targetCheck = false;
		
		String findWord = null;
		boolean isFind = false;
		String start = begin;
		
		List<String> wordList = new ArrayList<String>();
		for(int i=0 ; i<words.length ; i++){
			wordList.add(words[i]);
		}
		
		if(targetCheck){
			while(!isFind){
				findWord = compareWord(start, target,wordList);
				if(null == findWord || findWord.length() == 0){
					break;
				}else if(findWord.equals(target)){
					isFind = true;
					break;
				}else{
					start = findWord;
					answer++;
					wordList.remove(findWord);
				}
			}
		}
        return answer;
    }
    
    private static String compareWord(String begin, String target, List wordList) {
		
		String find = "";
		int cnt = 0;
		int a=0;
		
		while(wordList.size()>0){
			String tempWord = wordList.get(0).toString();
			for(int b=0 ; b<tempWord.length() ; b++){
				for(int c=0 ; c<begin.length() ; c++){
					if(begin.charAt(b) ==  tempWord.charAt(c)){
						cnt++;
					}
				}
			}
			wordList.remove(tempWord);
			if(cnt >=2){
				find = tempWord;
				break;
			}
		}
		
		return find;
	}
		
}
