package tct.prog.stackqueue;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

public class Stack01 {

	public static void main(String[] args) {
		int[] heights = {6,9,5,7,4};
		int[] result = solution(heights);

		System.out.println("answer : " + result);

	}

	public static int[] solution(int[] heights) {
		int[] answer = null;

		Stack<Integer> st = new Stack<>();
		List<Integer[]> rcv = new ArrayList<Integer[]>();
		for(int i =0 ;i<heights.length ; i++){
			st.push(heights[i]);
		}
		
		System.out.println(st.size());
		
		
		int start = 0;
		int top = 0;
		
		start = st.pop();
		
		while(!st.isEmpty()){
			System.out.println(start);
			top = st.peek();
			System.out.println(top);

			if(start<top){
				Integer[] tempInt = {start, top};
				st.pop();
				rcv.add(tempInt);
				start = top;
			}
		}
		
		System.out.println(rcv.size());
		for(int i=0 ; i<rcv.size() ; i++){
			Integer[] tempInteger = rcv.get(i);
			System.out.println(tempInteger[0]);
			System.out.println(tempInteger[1]);
		}
		
		
		
		return answer;
	}

	

}
