package tct.prog.completion;
import java.util.ArrayList;
import java.util.List;

public class SmallNumber {

	static List<String> comList = null;
	static List<String> outputList = null;
	static String[] output = null;
	static String maxStr = "";
	
	public static void main(String[] args) {
		int answer = solution("17");
		System.out.println(answer);
	}

	public static int solution(String numbers) {
        int answer = 0;

		int N= numbers.length();
		String[] numStr = new String[N];
		boolean[] visited = new boolean[N];
        comList = new ArrayList<String>();
        outputList = new ArrayList<String>();
		output = new String[N];

		for(int i=0 ; i< N ; i++){
			numStr[i] = numbers.charAt(i) + "";
		}

		for (int i = 1; i <= N; i++) {
			perm(numStr, visited, 0, N, i);
		}
		
		List<Integer> numList = new ArrayList<Integer>();
		for(int i=0 ; i<outputList.size() ; i++){
			int tempInt = Integer.parseInt(outputList.get(i));
			if(!numList.contains(tempInt)){
				if(!check(tempInt) && tempInt >1){
					numList.add(tempInt);
				}
			}
		}
        
        answer = numList.size();
        return answer;
    }
    
    static void perm(String[] arr, boolean[] visited, int depth, int n, int r) {
		if (depth == r) {
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < r; i++){
				sb.append(output[i]);
			}
			outputList.add(sb.toString());
			return;
		}
        
        for (int i = 0; i < n; i++) {
			if (visited[i] != true) {
				visited[i] = true;
				output[depth] = arr[i];
				perm(arr, visited, depth + 1, n, r);
				visited[i] = false;
				;
			}
		}
    }
    
    private static boolean check(int tempInt) {
		
		boolean result = false;
		;
		for(int i=2 ; i<tempInt ; i++) {
			if(tempInt%i == 0){
				result = true;
				break;
			}
		}
		return result;
	}

}
