package tct.swea.stackqueue;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class S9280 {

	public static void main(String[] args) {
		
		int n = 5;
		int m = 10;
		int[] r = {10,20,30,40,50};
		int[] w = {100,200,300,400,500,600,700,800,900,1000};
		int[] order = {1,2,3,4,5,6,-2,-4,7,-5,-6,8,-3,-7,9,-9,10,-1,-10,-8};
		int sum = 0;
		
		Queue <Integer> q = new LinkedList();
		Queue <Integer> rq = new LinkedList();
		
		for(int o : order){
			q.add(o);
		}
		
		int[] parkArea = {0,0,0,0,0};
		
		int temp = 0;
		while(!q.isEmpty()){
			temp = q.poll();
			if(temp<0){
				temp = temp*-1;
				for(int i=0 ; i< parkArea.length ;i++){
					
					if(parkArea[i] == temp){
						parkArea[i] = 0;
						System.out.println("�����Ϸ� : " + temp);
						//	��ݰ��
						sum += w[temp - 1] * r[i];
						System.out.println("�����Ϸ���: " + w[temp - 1] * r[i]);
						// ����� �� ����
						if(!rq.isEmpty()){
							parkArea[i] = rq.poll();
							System.out.println("������������Ϸ� : " + parkArea[i]);
						}
					}
				}
			}else{
				boolean parking = false;
				for(int i=0 ; i< parkArea.length ;i++){
					if(parkArea[i] == 0){
						parkArea[i] = temp;
						parking = true;
						System.out.println("�����Ϸ� : " + temp);
						break;
					}
				}
				if(!parking){
					rq.add(temp);
					System.out.println("���Ϸ� : " + temp);
				}
			}
		}
		
		System.out.println("sum : " + sum) ;
	}
}





