package tct.swea.stackqueue;

import java.util.Stack;

public class S8931 {

	public static void main(String[] args) {
		
		int[] amounts = {500, 600, 150, 0, 800, 2500, 5000, 0, 200, 400};
		
		int result = solution(amounts);
		System.out.println("sum : " + result) ;
	}
	
	public static int solution(int[] amounts) {
		int answer = 0;
		
		Stack<Integer> st = new Stack<Integer>();
		
		for(int amt : amounts){
			if(amt == 0){
				st.pop();
			}else{
				st.push(amt);
			}
		}
		
		while(!st.isEmpty()){
			answer += st.pop();
		}
		
		return answer;
	}
	
}





